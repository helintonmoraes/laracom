rateYo
======

A simple and flexible, jQuery star rating Plugin,

it uses SVG to render rating, so no images required.

just create a div, throw some styles, initialize and thats it!.

**Hover** to change the rating and **Click** to set.

**Documentation**:
http://prrashi.github.io/rateYo/

**Browser Support**:
Supported by all modern browsers from IE9
